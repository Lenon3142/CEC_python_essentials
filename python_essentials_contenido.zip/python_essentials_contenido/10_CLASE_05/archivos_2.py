lista = []
file = open('devices.txt','r')

for item in file:
    item = item.strip()
    print(item)
    lista.append(item)
file.close()

