file = open('devices.txt','a')
while True:
    newItem = input("Ingresar nuevo equipo: ")
    if newItem == "exit":
        print("Terminado")
        break
    else:
        file.write(newItem+"\n")
file.close()
