import pandas as pd

titulos = pd.read_csv('titles.csv')
print(titulos.head(10))
print("n\*2")
elenco = pd.read_csv('cast.csv')
print(elenco.head(10))