# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 15:36:01 2019

@author: UPS
"""
import numpy as np
espacio1 = np.arange(0,30,1)
print(espacio1)
print ("\n"*2)
espacio2 = np.linspace(50,100,5)
print(espacio2)