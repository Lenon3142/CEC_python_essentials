# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 15:37:06 2019

@author: UPS
"""
import numpy as np
identidad1 = np.eye(4,4)
print(identidad1)
print("\n"*2)
identidad2 = np.identity(4)
print(identidad2)