# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 15:34:07 2019

@author: UPS
"""
import numpy as np
unos = np.ones((10,10))
print(unos)