# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 16:01:16 2019

@author: UPS
"""
import numpy as np
a= np.array([2,4,8])
print(a.min())
print(a.max())
print(a.sum())