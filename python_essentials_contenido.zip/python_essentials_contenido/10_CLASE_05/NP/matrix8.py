# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 15:13:45 2019

@author: UPS
"""
# Crear una matriz con un solo valor
import numpy as np
full = np.full((5,5),8)
print(full)