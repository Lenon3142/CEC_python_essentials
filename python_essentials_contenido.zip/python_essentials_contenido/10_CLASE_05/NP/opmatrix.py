# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 16:05:52 2019

@author: UPS
"""
import numpy as np
x= np.array([(1,2,3),
             (3,4,5)])
y= np.array([(1,2,3),
             (3,4,5)])
print(x+y)
print("\n")
print(x-y)
print("\n")
print(x*y)
print("\n")
print(x/y)