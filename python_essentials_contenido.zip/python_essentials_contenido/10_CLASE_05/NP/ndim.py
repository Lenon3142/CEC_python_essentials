# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 15:40:09 2019

@author: UPS
"""
import numpy as np
a = np.array([(1,2,3),(4,5,6)])
print(a.ndim)