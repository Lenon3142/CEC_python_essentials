# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 15:24:01 2019

@author: UPS
"""
import numpy as np
a=np.array([7,8,9])
print(a)
print ("\n"*2)
b=np.array([(1,2,3),(4,5,6)])
print(b)