# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 15:35:16 2019

@author: UPS
"""
import numpy as np
vacia = np.empty((3,2))
print(vacia)