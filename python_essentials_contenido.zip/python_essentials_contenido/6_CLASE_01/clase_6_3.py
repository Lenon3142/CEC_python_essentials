def funlista(lista):
    for i in lista:
        print("Hola",i)
        print("\n")

funlista(["AA","BB", "CC"])

def app_lista(n):
    lista = []
    for i in range(1,n+1):
        lista.append(i)
    return lista

print(app_lista(6))




