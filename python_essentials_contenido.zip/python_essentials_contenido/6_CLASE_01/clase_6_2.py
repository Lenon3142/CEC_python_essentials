def clase_6_2(a, b):
    resta = a - b

    suma = a + b
    mult = a * b
    div = a / b
    print(resta)
    print(suma)
    print(mult)
    print(div)
    return resta, suma, mult, div

aa,bb,cc,dd = clase_6_2(a=4, b=7)
aa2 = aa + 5
bb2 = aa + 5
cc2 = aa + 5
dd2 = aa + 5

print(aa2)
print(bb2)

