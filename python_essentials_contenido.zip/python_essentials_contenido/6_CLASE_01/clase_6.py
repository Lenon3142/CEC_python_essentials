def clase_6(barrio,calle,num_casa):
    print("La dirección de entrega es :",barrio, calle, num_casa)

barrio = input("Ingrese el barrio: ")
calle = input("Ingrese la calle ")
num_casa = input("Ingrese el numero de casa")
clase_6(barrio,calle,num_casa)

