def fib(n):
    a,b = 0,1
    while a<=n:
        print(a,end = " ")
        a,b = b, a+b
    print()




#     n = 8
# lista = [1,1]
# for i in range(1,n):
#     val = lista[i]+lista[i-1]
#     lista = lista.append(val)
# print(lista)