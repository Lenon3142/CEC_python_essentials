import prog_fib

prog_fib.fib(30)