def readint(prompt, min, max):
    n=1
    while True:
#        try:
        n = int(input('ingrese un numero de -10 a 10:  '))
        print(type(n))
        if n != int(n):
#        except:
            print('Error: Error en el ingreso')
        elif n<-10 or n > 10:
#        except:
            print('Error: el valor no está en el rango permitido (-10..10)')
        else:
             print('Correcto'+" " + str(n))
             break

v = readint("Enter a number from -10 to 10: ", -10, 10)
#print("The number is:", v)
