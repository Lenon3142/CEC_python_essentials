# -*- coding: utf-8 -*-
"""
Created on Fri Mar  6 18:57:17 2020

@author: Juan Carlos
"""

try:
    import math
    import time
    import abracadabra

except:
    print('Una de sus importaciones ha fallado.')