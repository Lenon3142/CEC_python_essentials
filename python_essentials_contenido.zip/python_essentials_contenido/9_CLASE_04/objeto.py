class TheSimpleClass():
    pass
miprimerobjeto = TheSimpleClass()
obj1 = TheSimpleClass()
obj2 = TheSimpleClass()
