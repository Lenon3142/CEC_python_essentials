# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 12:31:55 2019

@author: Juan Carlos
"""

class TheSimplestClass:
    pass

myFirstObject = TheSimplestClass()
