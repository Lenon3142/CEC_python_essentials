name = input("Ingrese el nombre: ")
last = input("Ingrese el apellido: ")
location = input("Ingrese la dirección: ")
age = input("Ingrese la edad: ")
aga = str(age)
blank = " "
print(name+blank+last+blank+location+blank+age)

