import math, sys

pi = 3.1416
def sin():
    return 0.99999
print(pi)
print(sin())
print(math.pi)
print(math.sin(math.pi/2))

