from math import pi, sin

print(sin(pi))

