
def fibonacci(n):
    lista = [1,1]
    for i in range(2,n):
        val = lista[i]+lista[i-1]
        lista = lista.append(val)
    print(lista)


