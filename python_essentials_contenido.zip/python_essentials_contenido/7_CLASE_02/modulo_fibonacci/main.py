import module

module.fibonacci(8)