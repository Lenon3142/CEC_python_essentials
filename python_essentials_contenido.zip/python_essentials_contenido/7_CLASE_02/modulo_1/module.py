
print("Quiero ser un Modulo")