# -*- coding: utf-8 -*-
"""
Created on Sat Nov 30 08:10:52 2019

@author: CEC
"""

doblar = lambda num: num*2

print(doblar(2))