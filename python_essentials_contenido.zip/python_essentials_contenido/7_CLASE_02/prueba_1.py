lst = [[x for x in range(3)] for y in range(3)]
for r in range(3):
    for c in range(3):
        if lst[r][c] % 2 != 0:
            print("#")

print ("a", "b", "c", sep = "sep")

i = 0
while i < i - 1 :
    i += 1
    print("*")
else:
    print("*")


nativeVLAN = 1
dataVLAN = 100
if nativeVLAN == dataVLAN:
    print("The native VLAN and the data VLAN are the same.")
else:
    print("The native VLAN and the data VLAN are different.")
print(type(i))

