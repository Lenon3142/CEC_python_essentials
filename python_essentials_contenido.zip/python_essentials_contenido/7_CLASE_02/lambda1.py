# -*- coding: utf-8 -*-
"""
Created on Sat Nov 30 08:09:01 2019

@author: CEC
"""

sumar = lambda x,y: x+y

print(sumar(5,2))