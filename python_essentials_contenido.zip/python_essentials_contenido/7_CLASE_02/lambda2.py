# -*- coding: utf-8 -*-
"""
Created on Sat Nov 30 08:09:47 2019

@author: CEC
"""

revertir = lambda cadena: cadena[::-1]

print(revertir("Hola"))